import app from "./app";
import db from "./db/models";

const { sequelize } = db as any;

// Koristimo IIFE (Immediately Invoked Function Expression)
(async () => {
  try {
    // 1. Proveravamo konekciju sa bazom (pre pokretanja servera)
    await sequelize.authenticate();
    console.log("Connection has been established successfully.");

    // 2. Pokrećemo server samo ako je DB konekcija uspešna
    const PORT = parseInt(process.env.PORT || "8080", 10);
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server is running on port ${PORT}.`);
    });
    /*app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}.`);
    });*/
  } catch (error) {
    console.error("DB connection error:", error);
    process.exit(1);
    // DODATNO: Ako konekcija ne uspe, izađite iz procesa
    // U produkciji je dobra praksa izaći ako ne možete da se povežete na DB
    // process.exit(1);
  }
})();
/*(async () => {
  try {
    await sequelize.authenticate();
    console.log("Connection has been established successfully.");

    const PORT = process.env.PORT || 8080;
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}.`);
    });
  } catch (error) {
    console.error("DB connection error:", error);
    //  process.exit(1);
  }
})(); */
