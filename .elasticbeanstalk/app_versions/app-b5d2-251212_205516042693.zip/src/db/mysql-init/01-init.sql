CREATE DATABASE IF NOT EXISTS rag_db_test
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
