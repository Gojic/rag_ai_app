import swaggerJsdoc from "swagger-jsdoc";
import swaggerUi from "swagger-ui-express";

const options = {
  definition: {
    openapi: "3.0.0",
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
      },
    },
    info: {
      title: "RAG Backend API",
      version: "1.0.0",
      description:
        "API documentation for Retrieval-Augmented Generation system",
    },
    servers: [
      { url: "/" },
      {
        url: "http://rag-app-env.eba-tsxeffwp.eu-central-1.elasticbeanstalk.com",
      },
    ],
  },
  apis: ["./src/routes/*.ts"],
};
export const swaggerSpec = swaggerJsdoc(options);
export { swaggerUi };
